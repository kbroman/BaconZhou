## ------------------------------------------------------------------------
library(BrownMotion)
y <- BrownMotion(10000)
plot(y, type = 'l')

